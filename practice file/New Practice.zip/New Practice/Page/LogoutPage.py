import time

from selenium.webdriver.common.by import By

import Locators.LogoutPageLocators
from Page.BasePage import BasePage


class LogoutPage(BasePage):
    profile2 = (By.XPATH, Locators.LogoutPageLocators.profile2)
    logout = (By.XPATH, Locators.LogoutPageLocators.logout)

    def __init__(self, driver):
        super().__init__(driver)

    def do_logout(self):
        self.driver.refresh()   # to refresh the webpage.
        self.do_click(self.profile2)
        time.sleep(3)
        self.do_click(self.logout)
        time.sleep(3)
        self.driver.close()
        print('logged out')

