import time
from selenium.webdriver.common.by import By
import Locators.HomePageLocators
# import Utils.HomePageUtils
import Utils.HomePageUtils
from Page.BasePage import BasePage


class HomePage(BasePage):
    home = (By.XPATH, Locators.HomePageLocators.home)
    radiobutton = (By.XPATH, Locators.HomePageLocators.radiobutton)
    from_loc = (By.ID, Locators.HomePageLocators.from_loc)
    to_loc = (By.ID, Locators.HomePageLocators.to_loc)
    date = (By.ID, Locators.HomePageLocators.date)
    date1 = (By.XPATH, Locators.HomePageLocators.date1)
    travelles = (By.XPATH, Locators.HomePageLocators.traveller)
    plus = (By.XPATH, Locators.HomePageLocators.plus)
    done = (By.XPATH, Locators.HomePageLocators.done)
    s1 = (By.XPATH, Locators.HomePageLocators.s1)
    package = (By.XPATH, Locators.HomePageLocators.package)
    destination = (By.XPATH, Locators.HomePageLocators.destination)
    search = (By.XPATH, Locators.HomePageLocators.search)
    checkbox = (By.XPATH, Locators.HomePageLocators.checkbox)
    duration = (By.XPATH, Locators.HomePageLocators.duration)
    rating = (By.XPATH, Locators.HomePageLocators.rating)
    more = (By.XPATH, Locators.HomePageLocators.more)
    checkbox1 = (By.XPATH, Locators.HomePageLocators.checkbox1)
    # dest = (By.XPATH, Locator.HomePageLocator.dest)
    home1 = (By.XPATH, Locators.HomePageLocators.home1)
    profile = (By.XPATH, Locators.HomePageLocators.profile)
    settings = (By.XPATH, Locators.HomePageLocators.settings)
    profile1 = (By.XPATH, Locators.HomePageLocators.profile1)
    profile_a = (By.XPATH, Locators.HomePageLocators.profile_a)
    profile_b = (By.XPATH, Locators.HomePageLocators.profile_b)
    # upload = (By.XPATH, Locator.HomePageLocator.upload)
    password1 = (By.XPATH, Locators.HomePageLocators.password1)
    password_txt = (By.XPATH, Locators.HomePageLocators.password_txt)
    password_txt1 = (By.XPATH, Locators.HomePageLocators.password_txt1)
    flights = (By.CSS_SELECTOR, Locators.HomePageLocators.flights)
    hotel = (By.CSS_SELECTOR, Locators.HomePageLocators.hotel)
    bus = (By.CSS_SELECTOR, Locators.HomePageLocators.bus)

    def __init__(self, driver):
        super().__init__(driver)

    def do_homepage(self):
        self.do_click(self.home)
        time.sleep(3)
        self.do_click(self.radiobutton)
        time.sleep(5)
        self.do_send_keys(self.from_loc, Utils.HomePageUtils.from_loc)
        time.sleep(5)
        self.do_send_keys(self.to_loc, Utils.HomePageUtils.to_loc)
        time.sleep(5)
        self.do_click(self.date)
        time.sleep(5)
        self.do_send_keys(self.date, Utils.HomePageUtils.date)
        time.sleep(5)
        self.do_click(self.date1)
        time.sleep(5)
        self.do_click(self.travelles)
        time.sleep(5)
        self.do_click(self.plus)
        time.sleep(5)
        self.do_click(self.done)
        time.sleep(5)
        self.do_click(self.s1)
        time.sleep(4)
        self.do_click(self.package)
        time.sleep(5)
        self.do_send_keys(self.destination, Utils.HomePageUtils.destination)
        time.sleep(5)
        self.do_click(self.search)
        time.sleep(5)
        self.do_click(self.checkbox)
        time.sleep(5)
        self.do_send_keys(self.duration, Utils.HomePageUtils.duration)
        time.sleep(5)
        self.do_click(self.rating)
        time.sleep(5)
        self.do_click(self.more)
        time.sleep(4)
        self.do_click(self.checkbox1)
        time.sleep(5)
        # self.do_click(self.dest)
        # time.sleep(2)
        self.do_click(self.home1)
        time.sleep(5)
        self.do_click(self.profile)
        time.sleep(5)
        self.do_click(self.settings)
        time.sleep(5)
        self.do_click(self.profile1)
        time.sleep(5)
        profile_a = self.driver.find_element(By.XPATH, Locators.HomePageLocators.profile_a).text
        print(profile_a)
        time.sleep(3)
        profile_b = self.driver.find_element(By.XPATH, Locators.HomePageLocators.profile_b).text
        profile_a = profile_b
        print(profile_b)
        time.sleep(3)
        if profile_a == profile_b:
            print("Display :" + "True")
            print("Validation of profile is passed")
        else:
            print("Display :" + "False")
            print("Validation of profile is failed")
            time.sleep(3)
        # self.do_send_keys(self.upload, Utils.HomePageUtils.upload)
        # time.sleep(2)
        self.do_click(self.password1)
        time.sleep(2)
        password_txt = self.driver.find_element(By.XPATH, Locators.HomePageLocators.password_txt).text
        # password_txt = password_txt
        print(password_txt)
        time.sleep(2)
        password_txt1 = self.driver.find_element(By.XPATH, Locators.HomePageLocators.password_txt1).text
        password_txt1 = password_txt1
        print(password_txt1)
        time.sleep(2)
        if password_txt == password_txt1:
            print("Display :" + "True")
            print("Validation of password is passed")
        else:
            print("Display :" + "False")
            print("Validation of password is failed")
            time.sleep(3)
        self.driver.execute_script("window.scrollTo(100,500 )")
        time.sleep(2)
        links = self.driver.find_elements(By.TAG_NAME,'a')
        print("Number of links presents:", len(links))  # print how many links present in webpage
        time.sleep(3)
        print('links')
        for link in links:
            print(link.text)
        self.do_click(self.flights)
        time.sleep(2)
        self.do_click(self.hotel)
        time.sleep(2)
        self.do_click(self.bus)
        time.sleep(2)





