import time
from selenium.webdriver.common.by import By
from Page.BasePage import BasePage
import Locators.LoginPageLocators
import Utils.LoginPageUtils


class LoginPage(BasePage):
    username = (By.ID, Locators.LoginPageLocators.email)
    password = (By.ID, Locators.LoginPageLocators.password)
    submit = (By.NAME, Locators.LoginPageLocators.submit)

    def __init__(self, driver):
        super().__init__(driver)
        driver.maximize_window()
        driver.get(Utils.LoginPageUtils.url)

    def do_login(self, email, password):
        time.sleep(3)
        # self.do_click(self.Myaccnt)
        # time.sleep(3)
        # self.do_click(self.login)
        # time.sleep(3)
        self.do_send_keys(self.username, "ranihg0105@gmail.com")
        time.sleep(3)
        self.do_send_keys(self.password, "12345678")
        time.sleep(3)
        self.do_click(self.submit)
        time.sleep(3)
        print("Successfully loggedIn")
