from webdriver_manager.chrome import ChromeDriverManager


class TestData:
    chrome_executable_path = ChromeDriverManager().install()

    url = 'https://www.tripodeal.com/portal/login.php'
    email = "ranihg0105@gmail.com"
    password = "12345678"
