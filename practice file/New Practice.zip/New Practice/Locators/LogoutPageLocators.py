profile2 = '//*[@id="navbarDropdownMenuLink"]/img'
logout = '//*[@id="navbarText"]/ul[2]/li/div/a[4]'
