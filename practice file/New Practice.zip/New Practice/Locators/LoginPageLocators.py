#loginpage
# Myaccnt = 'navbarDropdown'
# login = '//*[@id="navbarText"]/ul[2]/li/div/a[2]'
email = 'email'
password = 'password'
submit = 'submit'

