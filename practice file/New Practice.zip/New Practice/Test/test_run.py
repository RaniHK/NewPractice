from ConfigPage.config import TestData
from Page.HomePage import HomePage
from Page.LoginPage import LoginPage
from Test.test_base import BaseTest
from Page.LogoutPage import LogoutPage


class TestLogin(BaseTest):
    loginpage = None
    homepage = None
    logout = None

    def test_login(self):
        self.loginpage = LoginPage(self.driver)
        global loginpage
        loginpage = self.loginpage.do_login(TestData.email, TestData.password)

    def test_homepage(self):
        self.homepage = HomePage(self.driver)
        global homepage
        homepage = self.homepage.do_homepage()

    def test_logoutpage(self):
        self.logoutpage = LogoutPage(self.driver)
        global logoutpage
        logoutpage = self.logoutpage.do_logout()

# from ConfigPage.config import TestData
# from Page.HomePage import HomePage
# from Page.LoginPage import LoginPage
# from Test.test_base import BaseTest
# from Page.LogoutPage import LogoutPage
#
# class TestLogin(BaseTest):
#     loginpage = None
#     homepage = None
#     logout = None
#
#     def test_login(self):
#         self.loginpage = LoginPage(self.driver)
#         global loginpage
#         loginpage = self.loginpage.do_login(TestData.email, TestData.password)
#
#     def test_homepage(self):
#         self.homepage = HomePage(self.driver)
#         global homepage
#         homepage = self.homepage.do_homepage()
#
#     def test_logoutpage(self):
#         self.logoutpage = LogoutPage(self.driver)
#         global logoutpage
#         logoutpage = self.logoutpage.do_logout()
#
#