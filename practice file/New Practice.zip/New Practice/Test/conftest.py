
import pytest
from selenium.webdriver.chrome import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium import webdriver

# from ConfigPage.config import TestData

web_driver = None


@pytest.fixture(params=["chrome"], scope='class')
def init_driver(request):
    global web_driver
    if request.param == "chrome":
        web_driver = webdriver.Chrome(executable_path=ChromeDriverManager().install())
    request.cls.driver = web_driver


